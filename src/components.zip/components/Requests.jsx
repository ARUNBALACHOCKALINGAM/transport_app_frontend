import React,{useContext,useEffect, useState} from "react"
import StateContext from "../StateContext";
import Card from '@mui/material/Card';
import { Button } from "@mui/material";
import Dispatchcontext from "../DispatchContext";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function Requests() {
  
  const navigate = useNavigate();
  const [details,setDetails] = useState();
  const appState = useContext(StateContext);
  const appDispatch = useContext(Dispatchcontext);
  const handleLogout = () =>{
    appDispatch({ type: "logout"});
    navigate('/');
  }

  useEffect(()=>{
     const fetchresults= async ()=>{
        const response= await axios.get('/orders');
        setDetails(response.data);
     }
     fetchresults();
  },[])
  
  
console.log(details);


  return (
    <>
    <h2>REQUESTS</h2>
    <Card elevation={4} style={{minWidth:"400px"}}>
     
        <div style={{display:"flex",justifyContent:"space-around",margin:"5px"}}>
        <h4>Name</h4>
        <h4>Source</h4>
        <h4>Destination</h4>
        <h4>Goods type</h4>
        <h4>Status</h4>
        </div>
    </Card>
    <Button onClick={handleLogout} style={{marginTop:"100px"}} variant='contained'>
            Logout
          </Button>
    </>
  )
}

export default Requests