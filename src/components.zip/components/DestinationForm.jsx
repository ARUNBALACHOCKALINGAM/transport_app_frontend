import * as React from 'react';
import StateContext from '../StateContext';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';

export default function AddressForm() {
  
  const appState = React.useContext(StateContext);
  console.log(appState.recieversDetails);
  const [firstname,setFirstname]=React.useState();
  const [lastname,setLastname]=React.useState();
  const [address,setAddress]=React.useState();
  const [city,setCity]=React.useState();
  const [state,setState]=React.useState();
  const [zipcode,setZipcode]=React.useState();
  const [country,setCountry]=React.useState();
  const [goodsdetails,setGoodsDetails]=React.useState();


  
  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        Destination address
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="firstName"
            value={firstname}
            onChange={(e)=>{
              setFirstname(e.target.value)
              appState.recieversDetails.firstname=e.target.value
            }}
            name="firstName"
            label="First name"
            fullWidth
            autoComplete="given-name"
            variant="standard"
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            value={lastname}
            onChange={(e)=>{
              setLastname(e.target.value)
              appState.recieversDetails.lastname=e.target.value
            }}
            id="lastName"
            name="lastName"
            label="Last name"
            fullWidth
            autoComplete="family-name"
            variant="standard"
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            required
            value={address}
            onChange={(e)=>{
              setAddress(e.target.value)
              appState.recieversDetails.address=e.target.value
            }}
            id="address1"
            name="address1"
            label="Address line 1"
            fullWidth
            autoComplete="shipping address-line1"
            variant="standard"
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            id="address2"
            name="address2"
            label="Address line 2"
            fullWidth
            autoComplete="shipping address-line2"
            variant="standard"
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="city"
            value={city}
            onChange={(e)=>{
              setCity(e.target.value)
              appState.recieversDetails.city=e.target.value
            }}
            name="city"
            label="City"
            fullWidth
            autoComplete="shipping address-level2"
            variant="standard"
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            id="state"
            value={state}
            onChange={(e)=>{
              setState(e.target.value)
              appState.recieversDetails.state=e.target.value
            }}
            name="state"
            label="State/Province/Region"
            fullWidth
            variant="standard"
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="zip"
            value={zipcode}
            onChange={(e)=>{
              setZipcode(e.target.value)
              appState.recieversDetails.zipcode=e.target.value
            }}
            name="zip"
            label="Zip / Postal code"
            fullWidth
            autoComplete="shipping postal-code"
            variant="standard"
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="country"
            value={country}
            onChange={(e)=>{
              setCountry(e.target.value)
              appState.recieversDetails.country=e.target.value
            }}
            name="country"
            label="Country"
            fullWidth
            autoComplete="shipping country"
            variant="standard"
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="goods"
            name="goods"
            value={goodsdetails}
            onChange={(e)=>{
              setGoodsDetails(e.target.value)
              appState.recieversDetails.goodstype=e.target.value
            }}
            label="Goods details"
            fullWidth
            autoComplete="shipping goods"
            variant="standard"
          />
        </Grid>
       
      </Grid>
    </React.Fragment>
  );
}